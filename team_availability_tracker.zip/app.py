from flask import Flask, render_template, request, jsonify
import sqlite3

app = Flask(__name__)

def get_db():
    conn = sqlite3.connect("database.db")
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    conn.execute('''
    CREATE TABLE IF NOT EXISTS team_members (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        role TEXT,
        available INTEGER
    )
    ''')

    count = conn.execute("SELECT COUNT(*) FROM team_members").fetchone()[0]

    if count == 0:
        members = [
            ("Alex Rivers", "Senior Developer", 1),
            ("Samantha Chen", "UX Designer", 0),
            ("Jordan Taylor", "Project Manager", 1),
            ("Maria Garcia", "Marketing Lead", 0)
        ]
        conn.executemany(
            "INSERT INTO team_members(name, role, available) VALUES(?,?,?)",
            members
        )

    conn.commit()
    conn.close()

@app.route("/")
def index():
    conn = get_db()
    members = conn.execute("SELECT * FROM team_members").fetchall()
    conn.close()
    return render_template("index.html", members=members)

@app.route("/toggle/<int:id>", methods=["POST"])
def toggle(id):
    conn = get_db()
    member = conn.execute(
        "SELECT available FROM team_members WHERE id=?",
        (id,)
    ).fetchone()

    new_status = 0 if member["available"] else 1

    conn.execute(
        "UPDATE team_members SET available=? WHERE id=?",
        (new_status, id)
    )

    conn.commit()
    conn.close()

    return jsonify({"success": True})

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
